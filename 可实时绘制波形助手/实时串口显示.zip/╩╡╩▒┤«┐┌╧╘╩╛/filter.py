# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 22:39:10 2020

@author: 16438
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

x=np.linspace(0,6,1000)
noise=np.random.normal(0,0.08,1000)
y1=np.sin(x)
y2=np.cos(x+0.124)
plt.plot(x,y1,x,y2)
plt.xlabel("t(μs)")
plt.ylabel("y(t)(V)")
plt.title("signal after noise")
plt.show()


# # FilterResponse.py
# def butterBandPassFilter(lowcut, highcut, samplerate, order):
#     "生成巴特沃斯带通滤波器"
#     semiSampleRate = samplerate * 0.5
#     low = lowcut / semiSampleRate
#     high = highcut / semiSampleRate
#     b, a = signal.butter(order, high, btype='lowpass')
#     plt.xlabel("w")
#     plt.ylabel("y(w)")
#     return b, a
#
#
# def butterBandStopFilter(lowcut, highcut, samplerate, order):
#     "生成巴特沃斯带阻滤波器"
#     semiSampleRate = samplerate * 0.5
#     low = lowcut / semiSampleRate
#     high = highcut / semiSampleRate
#     b, a = signal.butter(order, [low, high], btype='bandstop')
#     return b, a
#
#
# iSampleRate = 2000  # 采样频率
#
# plt.figure(figsize=(12, 5))
#
# for k in [2]:
#     b, a = butterBandPassFilter(3, 70, samplerate=iSampleRate, order=k)
#     w, h = signal.freqz(b, a, worN=2000)
#     plt.plot((iSampleRate * 0.5 / np.pi) * w, np.abs(h), label="order = %d" % k)
#
# # ax1 = plt.subplot(122)
# # for k in [2]:
# #     b, a = butterBandStopFilter(48, 52, samplerate=iSampleRate, order=k)
# #     w, h = signal.freqz(b, a, worN=2000)
# #     ax1.plot((iSampleRate * 0.5 / np.pi) * w, np.abs(h), label="order = %d" % k)
#
# plt.show()