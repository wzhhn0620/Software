import sys
import serial
import time
import threading
import serial.tools.list_ports
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import QTimer
from ui_demo_1 import Ui_Form
import pyqtgraph as pg
from pyqtgraph.Qt import  QtCore
from random import randint

global x_t
#判断字符串是否为数字
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False

def str2int(str):
    try:
        int(str)
        return int(str)
    except ValueError: #报类型错误，说明不是整型的
        try:
            float(str) #用这个来验证，是不是浮点字符串
            return int(float(str))
        except ValueError:  #如果报错，说明即不是浮点，也不是int字符串。   是一个真正的字符串
            return False

def toHex(num):
    """
    :type num: int
    :rtype: str
    """
    chaDic = {10: 'a', 11: 'b', 12: 'c', 13: 'd', 14: 'e', 15: 'f'}
    hexStr = ""

    if num < 0:
        num = num + 2 ** 32

    while num >= 16:
        digit = num % 16
        hexStr = chaDic.get(digit, str(digit)) + hexStr
        num //= 16
    hexStr = chaDic.get(num, str(num)) + hexStr

    return hexStr


def generate_str(length):
    """
    生成一个指定长度的随机字符串
    """
    random_str = ''
    base_str = '0'
    for i in range(length):
        random_str += base_str[0]
    return random_str



class Pyqt5_Serial(QtWidgets.QWidget, Ui_Form):
    def __init__(self):
        super(Pyqt5_Serial, self).__init__()
        self.setupUi(self)
        self.init()
        self.setWindowTitle("俺眼串口小助手")
        self.ser = serial.Serial()
        self.port_check()

        # 接收数据和发送数据数目置零
        self.data_num_received = 0
        self.lineEdit.setText(str(self.data_num_received))
        self.data_num_sended = 0
        x_t = 0
        self.deta_t = 1.167
        self.i_t = 0
        self.show_pic = 0
        self.data_count = 0
        self.CountStart1 = 0
        self.lineEdit_2.setText(str(self.data_num_sended))

    def init(self):
        # 串口检测按钮
        self.s1__box_1.clicked.connect(self.port_check)

        # 串口信息显示
        self.s1__box_2.currentTextChanged.connect(self.port_imf)

        # 打开串口按钮
        self.open_button.clicked.connect(self.port_open)

        # 关闭串口按钮
        self.close_button.clicked.connect(self.port_close)

        # 发送数据按钮
        self.s3__send_button.clicked.connect(self.data_send)

        # 定时发送数据
        self.timer_send = QTimer()
        self.timer_send.timeout.connect(self.data_send)
        self.timer_send_cb.stateChanged.connect(self.data_send_timer)

        # 定时器接收数据
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.data_receive)

        # 清除发送窗口
        self.s3__clear_button.clicked.connect(self.send_data_clear)

        # 清除接收窗口
        self.s2__clear_button.clicked.connect(self.receive_data_clear)


        self.dataPlot()

    def data_clean(self):
        self.i = 0
        self.i_t = 0
        self.x = []  # x轴的值
        self.y = []  # y轴的值
        self.show_pic = 0
        self.CountStart1 = 1

    # 串口检测
    def port_check(self):
        # 检测所有存在的串口，将信息存储在字典中
        self.Com_Dict = {}
        port_list = list(serial.tools.list_ports.comports())
        self.s1__box_2.clear()
        for port in port_list:
            self.Com_Dict["%s" % port[0]] = "%s" % port[1]
            self.s1__box_2.addItem(port[0])
        if len(self.Com_Dict) == 0:
            self.state_label.setText(" 无串口")

    # 串口信息
    def port_imf(self):
        # 显示选定的串口的详细信息
        imf_s = self.s1__box_2.currentText()
        if imf_s != "":
            self.state_label.setText(self.Com_Dict[self.s1__box_2.currentText()])

    # 打开串口
    def port_open(self):
        self.ser.port = self.s1__box_2.currentText()
        self.ser.baudrate = int(self.s1__box_3.currentText())
        self.ser.bytesize = int(self.s1__box_4.currentText())
        self.ser.stopbits = int(self.s1__box_6.currentText())
        self.ser.parity = self.s1__box_5.currentText()

        try:
            self.ser.open()
        except:
            QMessageBox.critical(self, "Port Error", "此串口不能被打开！")
            return None

        # 打开串口接收定时器，周期为2ms
        self.timer.start(2)

        if self.ser.isOpen():
            self.open_button.setEnabled(False)
            self.close_button.setEnabled(True)
            self.formGroupBox1.setTitle("串口状态（已开启）")

    # 关闭串口
    def port_close(self):
        self.timer.stop()
        self.timer_send.stop()
        try:
            self.ser.close()
        except:
            pass
        self.open_button.setEnabled(True)
        self.close_button.setEnabled(False)
        self.lineEdit_3.setEnabled(True)
        # 接收数据和发送数据数目置零
        self.data_num_received = 0
        self.lineEdit.setText(str(self.data_num_received))
        self.data_num_sended = 0
        self.lineEdit_2.setText(str(self.data_num_sended))
        self.formGroupBox1.setTitle("串口状态（已关闭）")

    # 发送数据
    def data_send(self):
        if self.ser.isOpen():
            input_s = self.s3__send_text.toPlainText()
            if input_s != "":
                # 非空字符串
                if self.hex_send.isChecked():
                    # hex发送
                    input_s = input_s.strip()
                    if is_number(input_s):
                        # print(eval(input_s))
                        if eval(input_s)>=1 and eval(input_s)<=300000:
                            self.data_clean()
                            if eval(input_s)<=10000 and eval(input_s)>100:
                                self.deta_t = (1/eval(input_s))*1000/20
                                x_t = 1
                                self.PicPlot.setLabel("bottom", "时间/ms")
                            elif eval(input_s)>10000:
                                self.deta_t = (1/eval(input_s))*1000000/20
                                x_t = 2
                                self.PicPlot.setLabel("bottom", "时间/us")
                            else:
                                self.deta_t = (1/eval(input_s))/20
                                self.PicPlot.setLabel("bottom", "时间/s")

                        a = eval(input_s)
                        input_s = toHex(a)
                        input_s = generate_str(8-len(input_s)) + input_s
                        print(input_s)

                        # elif eval(input_s)>=1 and eval(input_s)<1000:
                        #     self.data_clean()
                        #     self.deta_t =
                        #     self.xlabel_t = "时间/"

                    send_list = []
                    while input_s != '':
                        try:
                            num = int(input_s[0:2], 16)
                        except ValueError:
                            QMessageBox.critical(self, 'wrong data', '请输入十六进制数据，以空格分开!')
                            return None
                        input_s = input_s[2:].strip()
                        send_list.append(num)
                    input_s = bytes(send_list)
                else:
                    # ascii发送
                    input_s = (input_s + '\r\n').encode('utf-8')

                num = self.ser.write(input_s)
                self.data_num_sended += num
                self.lineEdit_2.setText(str(self.data_num_sended))
        else:
            pass

    # 接收数据
    def data_receive(self):
        try:
            num = self.ser.inWaiting()
        except:
            self.port_close()
            return None
        if num > 0:
            data = self.ser.read(num)
            self.data_count = self.data_count+1
            # if self.data_count == 30:
            #     self.data_count = 0
            #     self.CountStart1 = 1
            data = data[0:-2]
            plot_data = str2int(data)
            # print(data)
            if plot_data != False:
                if self.data_count == 1:
                    self.CountStart1 = 1
                    self.data_count = 0
                plot_data = plot_data*3.3/4096
                round(plot_data,2)
                # print(plot_data)
                # plot_data = data.hex()
                # plot_data_Int = int(plot_data[0:2],16)
                # plot_data_Dec = int(plot_data[2:4],16)
                # plot_data = plot_data_Int+plot_data_Dec/100
                if plot_data > 1.98 and self.show_pic==0 and self.CountStart1==1:
                    self.show_pic = 1
                    self.CountStart1 = 0
                elif plot_data < 0.05 and self.show_pic == 1:
                    self.CountStart1 = 1
                elif plot_data > 1.98 and self.show_pic==1 and self.CountStart1==1:
                    self.show_pic = 0
                    self.CountStart1 = 0

                # plot_data = int(plot_data,16)
                if self.show_pic == 1:
                    # print(plot_data)
                    self.i += 1
                    self.i_t = self.i*self.deta_t
                    self.x.append(self.i_t)
                    # 创建随机温度值
                    self.y.append(plot_data)
                    self.curve.setData(self.x, self.y)

            elif data == b'start':
                self.CountStart1 = 1
                print("start")


            num = len(data)
            # hex显示
            if self.hex_receive.checkState():
                out_s = ''
                for i in range(0, len(data)):
                    out_s = out_s + '{:02X}'.format(data[i]) + ' '
                self.s2__receive_text.insertPlainText(out_s)
            else:
                # 串口接收到的字符串为b'123',要转化成unicode字符串才能输出到窗口中去
                self.s2__receive_text.insertPlainText(data.decode('iso-8859-1'))

            # 统计接收字符的数量
            self.data_num_received += num
            self.lineEdit.setText(str(self.data_num_received))

            # 获取到text光标
            textCursor = self.s2__receive_text.textCursor()
            # 滚动到底部
            textCursor.movePosition(textCursor.End)
            # 设置光标到text中去
            self.s2__receive_text.setTextCursor(textCursor)
        else:
            pass

    # 定时发送数据
    def data_send_timer(self):
        if self.timer_send_cb.isChecked():
            self.timer_send.start(int(self.lineEdit_3.text()))
            self.lineEdit_3.setEnabled(False)
        else:
            self.timer_send.stop()
            self.lineEdit_3.setEnabled(True)

    # 清除显示
    def send_data_clear(self):
        self.s3__send_text.setText("")

    def receive_data_clear(self):
        self.s2__receive_text.setText("")
        self.data_clean()

    def dataPlot(self):
        self.PicPlot.setTitle("测量信号",
                         color='008080',
                         size='12pt')

        # 设置上下左右的label
        # self.PicPlot.setLabel("right", "")
        self.PicPlot.setLabel("left", "Y(t)")
        self.PicPlot.setLabel("bottom", "时间")

        # 设置Y轴 刻度 范围
        self.PicPlot.setYRange(min=0,  # 最小值
                          max=3)  # 最大值

        # 显示表格线
        self.PicPlot.showGrid(x=True, y=True)

        # 背景色改为白色
        self.PicPlot.setBackground('w')


        # 实时显示应该获取 plotItem， 调用setData，
        # 这样只重新plot该曲线，性能更高
        self.curve = self.PicPlot.getPlotItem().plot(
            pen=pg.mkPen('r', width=1)
        )

        self.i = 0
        self.x = []  # x轴的值
        self.y = []  # y轴的值

        # 启动定时器，每隔1秒通知刷新一次数据
        # self.timer = QtCore.QTimer()
        # self.timer.timeout.connect(self.updateData)
        # self.timer.start(500)


    def updateData(self):
        pass
        # self.i += 1
        # self.x.append(self.i)
        # # 创建随机温度值
        # self.y.append(10)
        #
        # # plot data: x, y values
        # self.curve.setData(self.x,self.y)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    myshow = Pyqt5_Serial()
    myshow.show()
    sys.exit(app.exec_())
